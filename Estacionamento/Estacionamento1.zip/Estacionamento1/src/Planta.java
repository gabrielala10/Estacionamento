import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JSeparator;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import java.awt.Dimension;
import java.awt.Component;
import java.awt.Rectangle;
import java.awt.Point;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import java.awt.Font;

public class Planta extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	private JTable table_2;
	private JTable table_3;
	private JTable table_4;
	private JTable table_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Planta frame = new Planta();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Planta() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 503, 336);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(Color.GRAY);
		menuBar.setBounds(0, 0, 340, 21);
		contentPane.add(menuBar);
		
		JButton btnEstacionar = new JButton("Estacionar");
		menuBar.add(btnEstacionar);
		
		JButton btnRetirarVeculo = new JButton("Retirar Ve\u00EDculo");
		menuBar.add(btnRetirarVeculo);
		
		JButton btnHistrico = new JButton("Hist\u00F3rico");
		menuBar.add(btnHistrico);
		
		JButton btnConfigurar = new JButton("Configurar");
		menuBar.add(btnConfigurar);
		
		JLabel lblTrreo = new JLabel("T\u00E9rreo");
		lblTrreo.setBounds(10, 32, 46, 14);
		contentPane.add(lblTrreo);
		
		JLabel lblAndar = new JLabel("1\u00B0 Andar");
		lblAndar.setBounds(263, 32, 46, 14);
		contentPane.add(lblAndar);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 57, 234, 106);
		contentPane.add(panel);
		
		table = new JTable();
		table.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 9));
		table.setColumnSelectionAllowed(true);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"},
				{"11", "12", "13", "14", "15", "16", "17", "18", "19", "20"},
				{"21", "22", "23", "24", "25", "26", "27", "28", "29", "30"},
				{"31", "32", "33", "34", "35", "36", "37", "38", "39", "40"},
				{"41", "42", "43", "44", "45", "46", "47", "48", "49", "50"},
				{"51", "52", "53", "54", "55", "56", "57", "58", "59", "60"},
			},
			new String[] {
				"New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(20);
		table.getColumnModel().getColumn(1).setPreferredWidth(20);
		table.getColumnModel().getColumn(2).setPreferredWidth(20);
		table.getColumnModel().getColumn(3).setPreferredWidth(20);
		table.getColumnModel().getColumn(4).setPreferredWidth(20);
		table.getColumnModel().getColumn(5).setPreferredWidth(20);
		table.getColumnModel().getColumn(6).setPreferredWidth(20);
		table.getColumnModel().getColumn(7).setPreferredWidth(20);
		table.getColumnModel().getColumn(8).setPreferredWidth(20);
		table.getColumnModel().getColumn(9).setPreferredWidth(20);
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		table.setToolTipText("Vagas");
		panel.add(table);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(9, 162, 235, 47);
		contentPane.add(panel_1);
		
		table_1 = new JTable();
		table_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 9));
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
				{"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"},
				{"11", "12", "13", "14", "15", "16", "17", "18", "19", "20"},
			},
			new String[] {
				"New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column"
			}
		));
		table_1.getColumnModel().getColumn(0).setPreferredWidth(20);
		table_1.getColumnModel().getColumn(1).setPreferredWidth(20);
		table_1.getColumnModel().getColumn(2).setPreferredWidth(20);
		table_1.getColumnModel().getColumn(3).setPreferredWidth(20);
		table_1.getColumnModel().getColumn(4).setPreferredWidth(20);
		table_1.getColumnModel().getColumn(5).setPreferredWidth(20);
		table_1.getColumnModel().getColumn(6).setPreferredWidth(20);
		table_1.getColumnModel().getColumn(7).setPreferredWidth(20);
		table_1.getColumnModel().getColumn(8).setPreferredWidth(20);
		table_1.getColumnModel().getColumn(9).setPreferredWidth(20);
		panel_1.add(table_1);
		table_1.setToolTipText("Vagas");
		table_1.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(9, 204, 235, 47);
		contentPane.add(panel_2);
		
		table_3 = new JTable();
		table_3.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 9));
		table_3.setModel(new DefaultTableModel(
			new Object[][] {
				{"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"},
				{"11", "12", "13", "14", "15", "16", "17", "18", "19", "20"},
			},
			new String[] {
				"New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column"
			}
		));
		table_3.getColumnModel().getColumn(0).setPreferredWidth(20);
		table_3.getColumnModel().getColumn(1).setPreferredWidth(20);
		table_3.getColumnModel().getColumn(2).setPreferredWidth(20);
		table_3.getColumnModel().getColumn(3).setPreferredWidth(20);
		table_3.getColumnModel().getColumn(4).setPreferredWidth(20);
		table_3.getColumnModel().getColumn(5).setPreferredWidth(20);
		table_3.getColumnModel().getColumn(6).setPreferredWidth(20);
		table_3.getColumnModel().getColumn(7).setPreferredWidth(20);
		table_3.getColumnModel().getColumn(8).setPreferredWidth(20);
		table_3.getColumnModel().getColumn(9).setPreferredWidth(20);
		table_3.setToolTipText("Vagas");
		table_3.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		panel_2.add(table_3);
		
		table_2 = new JTable();
		table_2.setToolTipText("Vagas");
		table_2.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		panel_2.add(table_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(243, 57, 234, 194);
		contentPane.add(panel_3);
		
		table_5 = new JTable();
		table_5.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 9));
		table_5.setRowSelectionAllowed(false);
		table_5.setBackground(new Color(224, 255, 255));
		table_5.setAutoCreateRowSorter(true);
		table_5.setModel(new DefaultTableModel(
			new Object[][] {
				{"61", "62", "63", "64", "65", "66", "67", "68", "69", "70"},
				{"71", "72", "73", "74", "75", "76", "77", "78", "79", "80"},
				{"81", "82", "83", "84", "85", "86", "87", "88", "89", "90"},
				{"91", "92", "93", "94", "95", "96", "97", "98", "99", "100"},
				{"101", "102", "103", "104", "105", "106", "107", "108", "109", "110"},
				{"111", "112", "113", "114", "115", "116", "117", "118", "119", "120"},
				{"121", "122", "123", "124", "125", "126", "127", "128", "129", "130"},
				{"131", "132", "133", "134", "135", "136", "137", "138", "139", "140"},
				{"141", "142", "143", "144", "145", "146", "147", "148", "149", "150"},
				{"151", "152", "153", "154", "155", "156", "154", "158", "159", "160"},
			},
			new String[] {
				"New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column"
			}
		));
		table_5.getColumnModel().getColumn(0).setPreferredWidth(21);
		table_5.getColumnModel().getColumn(0).setMinWidth(17);
		table_5.getColumnModel().getColumn(1).setPreferredWidth(21);
		table_5.getColumnModel().getColumn(2).setPreferredWidth(21);
		table_5.getColumnModel().getColumn(3).setPreferredWidth(21);
		table_5.getColumnModel().getColumn(4).setPreferredWidth(21);
		table_5.getColumnModel().getColumn(5).setPreferredWidth(21);
		table_5.getColumnModel().getColumn(6).setPreferredWidth(21);
		table_5.getColumnModel().getColumn(7).setPreferredWidth(21);
		table_5.getColumnModel().getColumn(8).setPreferredWidth(21);
		table_5.getColumnModel().getColumn(9).setPreferredWidth(21);
		table_5.setToolTipText("Vagas");
		table_5.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		panel_3.add(table_5);
		
		table_4 = new JTable();
		table_4.setToolTipText("Vagas");
		table_4.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		panel_3.add(table_4);
	}
}
