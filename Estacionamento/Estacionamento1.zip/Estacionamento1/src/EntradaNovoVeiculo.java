import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.BoxLayout;
import javax.swing.JTable;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.JButton;

public class EntradaNovoVeiculo extends JFrame {

	private JPanel contentPane;
	private JTextField Placa;
	private JTextField Dia;
	private JTextField M�s;
	private JTextField Ano;
	private JTextField Hora;
	private JTextField Minuto;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EntradaNovoVeiculo frame = new EntradaNovoVeiculo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EntradaNovoVeiculo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 353, 246);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblVeculo = new JLabel("Ve\u00EDculo:");
		lblVeculo.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		lblVeculo.setBounds(10, 11, 46, 14);
		contentPane.add(lblVeculo);
		
		JRadioButton rdbtnCarro = new JRadioButton("Carro");
		rdbtnCarro.setFont(new Font("Yu Gothic UI", Font.PLAIN, 15));
		rdbtnCarro.setBounds(74, 8, 61, 23);
		contentPane.add(rdbtnCarro);
		
		JRadioButton rdbtnMoto = new JRadioButton("Moto");
		rdbtnMoto.setFont(new Font("Yu Gothic UI", Font.PLAIN, 15));
		rdbtnMoto.setBounds(135, 8, 61, 23);
		contentPane.add(rdbtnMoto);
		
		JRadioButton rdbtnCaminhonete = new JRadioButton("Caminhonete");
		rdbtnCaminhonete.setFont(new Font("Yu Gothic UI", Font.PLAIN, 15));
		rdbtnCaminhonete.setBounds(198, 9, 133, 20);
		contentPane.add(rdbtnCaminhonete);
		
		JLabel lblPlaca = new JLabel("Placa:");
		lblPlaca.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		lblPlaca.setBounds(10, 51, 46, 14);
		contentPane.add(lblPlaca);
		
		Placa = new JTextField();
		Placa.setBounds(74, 49, 241, 20);
		contentPane.add(Placa);
		Placa.setColumns(10);
		
		JLabel lblData = new JLabel("Data:");
		lblData.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		lblData.setBounds(10, 92, 46, 14);
		contentPane.add(lblData);
		
		JLabel lblHora = new JLabel("Hora:");
		lblHora.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		lblHora.setBounds(10, 138, 46, 14);
		contentPane.add(lblHora);
		
		Dia = new JTextField();
		Dia.setBounds(74, 89, 46, 20);
		contentPane.add(Dia);
		Dia.setColumns(10);
		
		M�s = new JTextField();
		M�s.setColumns(10);
		M�s.setBounds(135, 89, 46, 20);
		contentPane.add(M�s);
		
		Ano = new JTextField();
		Ano.setColumns(10);
		Ano.setBounds(201, 89, 66, 20);
		contentPane.add(Ano);
		
		Hora = new JTextField();
		Hora.setBounds(74, 136, 46, 20);
		contentPane.add(Hora);
		Hora.setColumns(10);
		
		Minuto = new JTextField();
		Minuto.setColumns(10);
		Minuto.setBounds(135, 136, 46, 20);
		contentPane.add(Minuto);
		
		JLabel label = new JLabel(":");
		label.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		label.setBounds(124, 133, 46, 20);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("/");
		label_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		label_1.setBounds(124, 93, 46, 14);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("/");
		label_2.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		label_2.setBounds(191, 93, 46, 14);
		contentPane.add(label_2);
		
		JButton btnEstacionar = new JButton("Estacionar");
		btnEstacionar.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		btnEstacionar.setBounds(111, 173, 117, 23);
		contentPane.add(btnEstacionar);
	}
}
