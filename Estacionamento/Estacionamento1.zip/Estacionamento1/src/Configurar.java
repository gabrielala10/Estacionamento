import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import javax.swing.JButton;

public class Configurar extends JFrame {

	private JPanel contentPane;
	private JTextField horaCarro;
	private JTextField horaMoto;
	private JTextField horaCaminhonete;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Configurar frame = new Configurar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Configurar() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 248, 248);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSelecioneACategoria = new JLabel("Selecione a categoria a ser editada:");
		lblSelecioneACategoria.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		lblSelecioneACategoria.setBounds(6, 11, 230, 14);
		contentPane.add(lblSelecioneACategoria);
		
		JCheckBox chckbxCarro = new JCheckBox("Carro");
		chckbxCarro.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		chckbxCarro.setBounds(6, 58, 97, 23);
		contentPane.add(chckbxCarro);
		
		JCheckBox chckbxMoto = new JCheckBox("Moto");
		chckbxMoto.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		chckbxMoto.setBounds(6, 101, 97, 23);
		contentPane.add(chckbxMoto);
		
		JCheckBox chckbxCaminhonete = new JCheckBox("Caminhonete");
		chckbxCaminhonete.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		chckbxCaminhonete.setBounds(6, 140, 97, 23);
		contentPane.add(chckbxCaminhonete);
		
		JLabel lblNovoValor = new JLabel("Nova taxa por hora:");
		lblNovoValor.setFont(new Font("Tw Cen MT Condensed", Font.PLAIN, 14));
		lblNovoValor.setBounds(139, 37, 97, 14);
		contentPane.add(lblNovoValor);
		
		horaCarro = new JTextField();
		horaCarro.setBounds(150, 59, 66, 20);
		contentPane.add(horaCarro);
		horaCarro.setColumns(10);
		
		horaMoto = new JTextField();
		horaMoto.setColumns(10);
		horaMoto.setBounds(150, 102, 66, 20);
		contentPane.add(horaMoto);
		
		horaCaminhonete = new JTextField();
		horaCaminhonete.setColumns(10);
		horaCaminhonete.setBounds(150, 141, 66, 20);
		contentPane.add(horaCaminhonete);
		
		JLabel lblR = new JLabel("R$");
		lblR.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		lblR.setBounds(119, 62, 32, 14);
		contentPane.add(lblR);
		
		JLabel label = new JLabel("R$");
		label.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		label.setBounds(119, 106, 32, 14);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("R$");
		label_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		label_1.setBounds(119, 145, 32, 14);
		contentPane.add(label_1);
		
		JButton btnConcluido = new JButton("Concluido");
		btnConcluido.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		btnConcluido.setBounds(74, 182, 89, 23);
		contentPane.add(btnConcluido);
	}
}
